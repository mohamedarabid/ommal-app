<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Controllers\ControllersService;
use App\Models\Tender;
use App\Models\TenderRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TenderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $Tenders = Tender::paginate(10);
        $resonseData = [];
        foreach ($Tenders as $key => $Tender) {

            $resonseData['Tender'][$key]['id']         = $Tender->id;
            $resonseData['Tender'][$key]['name']       = $Tender->name;
            $resonseData['Tender'][$key]['desc']       = $Tender->desc;
            if ($Tender->contractor_id == request()->user('contractor_api')->id) {
                $resonseData['Tender'][$key]['owend']       = true;
            } else {
                $resonseData['Tender'][$key]['owend']       = false;
            }
        }
        $pagination['count'] = $Tenders->count();
        $pagination['hasMorePages'] = $Tenders->hasMorePages();
        $pagination['currentPage'] = $Tenders->currentPage();
        $pagination['firstItem'] = $Tenders->firstItem();
        $pagination['last_page_id'] = $Tenders->lastPage();
        $pagination['per_page'] = $Tenders->perPage();
        $pagination['nextPageUr l'] = $Tenders->nextPageUrl();
        $pagination['onFirstPage'] = $Tenders->onFirstPage();
        $pagination['previousPageUrl'] = $Tenders->previousPageUrl();
        $resonseData['paginate'] = $pagination;

        return response()->json([
            'status' => true,
            'message' => 'Success',
            'data' => $resonseData
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $roles = [
            'name' => 'required|string|min:3',
            'desc' => 'required|string|min:3',
            'long' => 'required',
            'lat' => 'required',
            'file' => 'required',

        ];
        $validator = Validator::make($request->all(), $roles);
        if (!$validator->fails()) {
            $user = new Tender();
            $user->name = $request->get('name');
            $user->desc = $request->get('desc');
            $user->long = $request->get('long');
            $user->lat = $request->get('lat');
            $user->status = 'active';
            $user->contractor_id = $request->user('contractor_api')->id;

            if ($request->hasFile('file')) {
                $userImage = $request->file('file');
                $imageName = time() . '_' . $request->get('first_name') . '.' . $userImage->getClientOriginalExtension();
                $userImage->move('file/Tender', $imageName);
                $user->file = '/file/Tender/' . $imageName;
            }
            $isSaved = $user->save();
            if ($isSaved) {
                return ControllersService::generateProcessResponse(true, 'CREATE_SUCCESS');
            } else {
                return ControllersService::generateProcessResponse(false, 'LOGIN_IN_FAILED');
            }
        } else {
            return ControllersService::generateValidationErrorMessage($validator->getMessageBag()->first());
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $Tender = Tender::find($id);
        $resonseData['id']         = $Tender->id;
        $resonseData['name']       = $Tender->name;
        $resonseData['desc']       = $Tender->desc;
        $resonseData['long']       = $Tender->long;
        $resonseData['lat']       = $Tender->lat;
        $resonseData['file']       = url($Tender->file);
        return response()->json([
            'status' => true,
            'message' => 'Success',
            'data' => $resonseData
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $roles = [
            'name' => 'nullable|string|min:3',
            'desc' => 'nullable|string|min:3',
            'long' => 'nullable',
            'lat' => 'nullable',
            'file' => 'nullable',

        ];
        $validator = Validator::make($request->all(), $roles);
        if (!$validator->fails()) {
            $user =  Tender::find($id);
            $user->name = $request->get('name');
            $user->desc = $request->get('desc');
            $user->long = $request->get('long');
            $user->lat = $request->get('lat');
            $user->status = $request->get('status');
            if ($request->hasFile('file')) {
                $userImage = $request->file('file');
                $imageName = time() . '_' . $request->get('first_name') . '.' . $userImage->getClientOriginalExtension();
                $userImage->move('file/Tender', $imageName);
                $user->file = '/file/Tender/' . $imageName;
            }
            $isSaved = $user->save();
            if ($isSaved) {
                return ControllersService::generateProcessResponse(true, 'UPDATE_SUCCESS');
            } else {
                return ControllersService::generateProcessResponse(false, 'UPDATE_FAILED');
            }
        } else {
            return ControllersService::generateValidationErrorMessage($validator->getMessageBag()->first());
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function requestTender(Request $request)
    {
        $roles = [
            'file' => 'required',
            'budget' => 'required',
        ];
        $validator = Validator::make($request->all(), $roles);
        if (!$validator->fails()) {
            $user = new TenderRequest();
            $user->budget = $request->get('budget');
            $user->tender_id = $request->get('tender_id');
            $user->currency_id = $request->get('currency_id');
            $user->contractor_id = $request->user('contractor_api')->id;
            $user->status = 'pending';
            if ($request->hasFile('file')) {
                $userImage = $request->file('file');
                $imageName = time() . '_' . $request->get('first_name') . '.' . $userImage->getClientOriginalExtension();
                $userImage->move('file/Tender', $imageName);
                $user->file = '/file/Tender/' . $imageName;
            }
            $isSaved = $user->save();
            if ($isSaved) {
                return ControllersService::generateProcessResponse(true, 'CREATE_SUCCESS');
            } else {
                return ControllersService::generateProcessResponse(false, 'LOGIN_IN_FAILED');
            }
        } else {
            return ControllersService::generateValidationErrorMessage($validator->getMessageBag()->first());
        }
    }
    public function showTenderRequest($id)
    {
        $Tender = TenderRequest::find($id);
        $resonseData['id']         = $Tender->id;
        $resonseData['budget']       = $Tender->budget;
        $resonseData['currency']       = $Tender->currency->name;
        $resonseData['file']       = url($Tender->file);
        $resonseData['contractor']       = $Tender->contractor->first_name . '' . $Tender->contractor->father_name . '' . $Tender->contractor->grand_name . '' . $Tender->contractor->family_name;
        return response()->json([
            'status' => true,
            'message' => 'Success',
            'data' => $resonseData
        ]);
    }
    public function ChangeStatus(Request $request, $id)
    {
        $roles = [
            'status' => 'nullable',

        ];
        $validator = Validator::make($request->all(), $roles);
        if (!$validator->fails()) {
            $TenderRequest =  TenderRequest::find($id);
            if ($TenderRequest->status == 'accept') {
                $TenderRequest->status = 'reject';
            } else {
                $TenderRequest->status = 'accept';
            }
            $isSaved = $TenderRequest->save();
            if ($isSaved) {
                return ControllersService::generateProcessResponse(true, 'UPDATE_SUCCESS');
            } else {
                return ControllersService::generateProcessResponse(false, 'UPDATE_FAILED');
            }
        } else {
            return ControllersService::generateValidationErrorMessage($validator->getMessageBag()->first());
        }
    }
    public function TenderRequest()
    {
        $Tenders = TenderRequest::paginate(10);
        $TendersCount = TenderRequest::count();
        $resonseData = [];
        foreach ($Tenders as $key => $Tender) {

            $resonseData['Tender'][$key]['id']         = $Tender->id;
            $resonseData['Tender'][$key]['file']         = url($Tender->file);
            $resonseData['Tender'][$key]['name']       = $Tender->contractor->first_name . '' . $Tender->contractor->father_name . '' . $Tender->contractor->grand_name . '' . $Tender->contractor->family_name;
            $resonseData['Tender'][$key]['count_request'] = $TendersCount;
        }
        $pagination['count'] = $Tenders->count();
        $pagination['hasMorePages'] = $Tenders->hasMorePages();
        $pagination['currentPage'] = $Tenders->currentPage();
        $pagination['firstItem'] = $Tenders->firstItem();
        $pagination['last_page_id'] = $Tenders->lastPage();
        $pagination['per_page'] = $Tenders->perPage();
        $pagination['nextPageUr l'] = $Tenders->nextPageUrl();
        $pagination['onFirstPage'] = $Tenders->onFirstPage();
        $pagination['previousPageUrl'] = $Tenders->previousPageUrl();
        $resonseData['paginate'] = $pagination;

        return response()->json([
            'status' => true,
            'message' => 'Success',
            'data' => $resonseData
        ]);
    }
}
