<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Controllers\ControllersService;
use App\Models\currency;
use App\Models\Job;
use App\Models\JobRequest;
use App\Models\JobSalary;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class JobController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $Jobs = Job::where('contractor_id', request()->user('contractor_api')->id)->paginate(10);

        $Jobs = $Jobs->paginate(10);
        $resonseData = [];
        foreach ($Jobs as $key => $Job) {

            $resonseData['job'][$key]['id']         = $Job->id;
            $resonseData['job'][$key]['name']       = $Job->name;
            $resonseData['job'][$key]['desc']       = $Job->desc;
            $resonseData['job'][$key]['status']       = $Job->status;
        }
        $pagination['count'] = $Job->count();
        $pagination['hasMorePages'] = $Job->hasMorePages();
        $pagination['currentPage'] = $Job->currentPage();
        $pagination['firstItem'] = $Job->firstItem();
        $pagination['last_page_id'] = $Job->lastPage();
        $pagination['per_page'] = $Job->perPage();
        $pagination['nextPageUrl'] = $Job->nextPageUrl();
        $pagination['onFirstPage'] = $Job->onFirstPage();
        $pagination['previousPageUrl'] = $Job->previousPageUrl();
        $resonseData['paginate'] = $pagination;

        return response()->json([
            'status' => true,
            'message' => 'Success',
            'data' => $resonseData
        ]);
    }
    public function indexJobs(Request $request)
    {

        $Jobs = Job::where('contractor_id', $request->user('contractor_api')->id);
        if ($request->get('orderBy') == 'desc') {
            $Jobs = $Jobs->orderBy('created_at', 'desc');
        } elseif ($request->get('orderBy') == 'asc') {
            $Jobs = $Jobs->orderBy('created_at', 'asc');
        }
        if ($request->get('from')) {
            $Jobs = $Jobs->whereBetween('date', [$request->get('from'), $request->get('to')]);
        }
        if ($request->get('lat') && $request->get('long')) {
            $Jobs = $Jobs->where('lat', $request->get('lat'))->where('long', $request->get('long'));
        }
        if ($request->get('name')) {
            $Jobs = $Jobs->where('name',  'LIKE', '%' . $request->get('name') . '%');
        }
        $Jobs = $Jobs->paginate(10);
        $resonseData = [];
        foreach ($Jobs as $key => $Job) {

            $resonseData['job'][$key]['id']         = $Job->id;
            $resonseData['job'][$key]['name']       = $Job->name;
            $resonseData['job'][$key]['desc']       = $Job->desc;
            $resonseData['job'][$key]['status']       = $Job->status;
        }
        $pagination['count'] = $Jobs->count();
        $pagination['hasMorePages'] = $Jobs->hasMorePages();
        $pagination['currentPage'] = $Jobs->currentPage();
        $pagination['firstItem'] = $Jobs->firstItem();
        $pagination['last_page_id'] = $Jobs->lastPage();
        $pagination['per_page'] = $Jobs->perPage();
        $pagination['nextPageUrl'] = $Jobs->nextPageUrl();
        $pagination['onFirstPage'] = $Jobs->onFirstPage();
        $pagination['previousPageUrl'] = $Jobs->previousPageUrl();
        $resonseData['paginate'] = $pagination;

        return response()->json([
            'status' => true,
            'message' => 'Success',
            'data' => $resonseData
        ]);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $roles = [
            'name' => 'required|string|min:3',
            'desc' => 'required|string|min:3',
            'long' => 'required',
            'lat' => 'required',
            'date' => 'required',
            'job_salary_id' => 'required',
            'currency_id' => 'required',
            'salary' => 'required',
        ];
        $validator = Validator::make($request->all(), $roles);
        if (!$validator->fails()) {
            $user = new Job();
            $user->name = $request->get('name');
            $user->desc = $request->get('desc');
            $user->long = $request->get('long');
            $user->lat = $request->get('lat');
            $user->date = $request->get('date');
            $user->salary = $request->get('salary');
            $user->overnight = $request->get('overnight');
            $user->health_inssurance = $request->get('health_inssurance');
            $user->permission = $request->get('permission');
            $user->contractor_id = $request->user('contractor_api')->id;
            $user->currency_id = $request->get('currency_id');
            $user->job_salary_id = $request->get('job_salary_id');
            $isSaved = $user->save();
            if ($isSaved) {
                return ControllersService::generateProcessResponse(true, 'CREATE_SUCCESS');
            } else {
                return ControllersService::generateProcessResponse(false, 'CREATE_FAILED');
            }
        } else {
            return ControllersService::generateValidationErrorMessage($validator->getMessageBag()->first());
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $Job = Job::find($id);
        $resonseData['id']         = $Job->id;
        $resonseData['name']       = $Job->name;
        $resonseData['desc']       = $Job->desc;
        $resonseData['long']       = $Job->long;
        $resonseData['status']       = $Job->status;
        $resonseData['overnight']       = $Job->overnight;
        $resonseData['health_inssurance']       = $Job->health_inssurance;
        $resonseData['permission']       = $Job->permission;
        $resonseData['currency']       = $Job->currency->name;
        $resonseData['job_salary']       = $Job->JobSalary->name;

        return response()->json([
            'status' => true,
            'message' => 'Success',
            'data' => $resonseData
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $roles = [
            'name' => 'nullable|string|min:3',
            'desc' => 'nullable|string|min:3',
            'long' => 'nullable',
            'lat' => 'nullable',
            'date' => 'nullable',
            'job_salary_id' => 'nullable',
            'currency_id' => 'nullable',
            'salary' => 'nullable',
        ];
        $validator = Validator::make($request->all(), $roles);
        if (!$validator->fails()) {
            $user =  Job::find($id);
            $user->name = $request->get('name');
            $user->desc = $request->get('desc');
            $user->long = $request->get('long');
            $user->date = $request->get('date');
            $user->salary = $request->get('salary');
            $user->overnight = $request->get('overnight');
            $user->health_inssurance = $request->get('health_inssurance');
            $user->permission = $request->get('permission');
            $user->currency_id = $request->get('currency_id');
            $user->job_salary_id = $request->get('job_salary_id');
            $user->status = 'active';
            $isSaved = $user->save();
            if ($isSaved) {
                return ControllersService::generateProcessResponse(true, 'UPDATE_SUCCESS');
            } else {
                return ControllersService::generateProcessResponse(false, 'UPDATE_FAILED');
            }
        } else {
            return ControllersService::generateValidationErrorMessage($validator->getMessageBag()->first());
        }
    }
    public function ChangeStatus(Request $request, $id)
    {
        $roles = [
            'status' => 'nullable',

        ];
        $validator = Validator::make($request->all(), $roles);
        if (!$validator->fails()) {
            $Job =  Job::find($id);
            if ($Job->status == 'stop') {
                $Job->status = 'active';
            } else {
                $Job->status = 'stop';
            }
            $isSaved = $Job->save();
            if ($isSaved) {
                return ControllersService::generateProcessResponse(true, 'UPDATE_SUCCESS');
            } else {
                return ControllersService::generateProcessResponse(false, 'UPDATE_FAILED');
            }
        } else {
            return ControllersService::generateValidationErrorMessage($validator->getMessageBag()->first());
        }
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function currency()
    {
        $currency = currency::all();
        $resonseData = [];
        foreach ($currency as $key => $currencies) {

            $resonseData['currency'][$key]['id']         = $currencies->id;
            $resonseData['currency'][$key]['name']       = $currencies->name;
        }
        return response()->json([
            'status' => true,
            'message' => 'Success',
            'data' => $resonseData
        ]);
    }
    public function jobType()
    {
        $JobSalary = JobSalary::all();
        $resonseData = [];
        foreach ($JobSalary as $key => $JobSalaries) {
            $resonseData['JobSalary'][$key]['id']         = $JobSalaries->id;
            $resonseData['JobSalary'][$key]['name']       = $JobSalaries->name;
        }
        return response()->json([
            'status' => true,
            'message' => 'Success',
            'data' => $resonseData
        ]);
    }
    public function requestJob(Request $request)
    {
        $roles = [
            'job_id' => 'required',
        ];
        $validator = Validator::make($request->all(), $roles);
        if (!$validator->fails()) {
            $user = new JobRequest();
            $user->job_id = $request->get('job_id');
            $user->worker_id = $request->user('worker_api')->id;
            $user->status = 'pending';

            $isSaved = $user->save();
            if ($isSaved) {
                return ControllersService::generateProcessResponse(true, 'CREATE_SUCCESS');
            } else {
                return ControllersService::generateProcessResponse(false, 'LOGIN_IN_FAILED');
            }
        } else {
            return ControllersService::generateValidationErrorMessage($validator->getMessageBag()->first());
        }
    }
    public function indexJobsWorker(Request $request)
    {

        if ($request->get('orderBy') == 'desc') {
            $Jobs = Job::orderBy('created_at', 'desc')->paginate(10);
        } elseif ($request->get('orderBy') == 'asc') {
            $Jobs = Job::orderBy('created_at', 'asc')->paginate(10);
        }
        if ($request->get('from')) {
            $Jobs = Job::whereBetween('date', [$request->get('from'), $request->get('to')])->paginate(10);
        }
        if ($request->get('lat') && $request->get('long')) {
            $Jobs = Job::where('lat', $request->get('lat'))->where('long', $request->get('long'))->paginate(10);
        }
        if ($request->get('name')) {
            $Jobs = Job::where('name',  'LIKE', '%' . $request->get('name') . '%')->paginate(10);
        }
        if ($request->get('orderBy') == null && $request->get('name') == null &&  $request->get('from') == null &&  $request->get('lat') == null) {
            $Jobs = Job::orderBy('created_at', 'desc')->paginate(10);
        }
        $user = $request->user('worker_api')->id;
        $resonseData = [];
        foreach ($Jobs as $key => $Job) {

            $resonseData['job'][$key]['id']         = $Job->id;
            $resonseData['job'][$key]['name']       = $Job->name;
            $resonseData['job'][$key]['desc']       = $Job->desc;
            $resonseData['job'][$key]['status']       = $Job->status;
            $request = JobRequest::where('job_id', $Job->id)
                ->where('worker_id', $user)->first();

            if ($request != null) {
                $resonseData['job'][$key]['request_appliad']       = true;
            } else {
                $resonseData['job'][$key]['request_appliad']       = false;
            }
        }
        $pagination['count'] = $Jobs->count();
        $pagination['hasMorePages'] = $Jobs->hasMorePages();
        $pagination['currentPage'] = $Jobs->currentPage();
        $pagination['firstItem'] = $Jobs->firstItem();
        $pagination['last_page_id'] = $Jobs->lastPage();
        $pagination['per_page'] = $Jobs->perPage();
        $pagination['nextPageUrl'] = $Jobs->nextPageUrl();
        $pagination['onFirstPage'] = $Jobs->onFirstPage();
        $pagination['previousPageUrl'] = $Jobs->previousPageUrl();
        $resonseData['paginate'] = $pagination;

        return response()->json([
            'status' => true,
            'message' => 'Success',
            'data' => $resonseData
        ]);
    }

    public function indexMyJobsWorker(Request $request)
    {
        $Jobs = JobRequest::with('Job')->where('worker_id', $request->user('worker_api')->id)->orderBy('created_at', 'desc');
        if ($request->get('orderBy') == 'desc') {
            $Jobs = JobRequest::orderBy('created_at', 'desc');
        } elseif ($request->get('orderBy') == 'asc') {
            $Jobs = JobRequest::orderBy('created_at', 'asc');
        }
        if ($request->get('from')) {
            $Jobs = JobRequest::whereBetween('date', [$request->get('from'), $request->get('to')]);
        }
        if ($request->get('lat') && $request->get('long')) {
            $Jobs = JobRequest::where('lat', $request->get('lat'))->where('long', $request->get('long'));
        }
        if ($request->get('name')) {
            $Jobs = JobRequest::where('name',  'LIKE', '%' . $request->get('name') . '%');
        }

        $Jobs = $Jobs->paginate(10);
        $resonseData = [];
        foreach ($Jobs as $key => $Job) {

            $resonseData['job'][$key]['id']         = $Job->id;
            $resonseData['job'][$key]['name']       = $Job->Job->name;
            $resonseData['job'][$key]['desc']       = $Job->Job->desc;
            $resonseData['job'][$key]['status']       = $Job->Job->status;
            $resonseData['job'][$key]['created_at']       = $Job->created_at;
        }
        $pagination['count'] = $Jobs->count();
        $pagination['hasMorePages'] = $Jobs->hasMorePages();
        $pagination['currentPage'] = $Jobs->currentPage();
        $pagination['firstItem'] = $Jobs->firstItem();
        $pagination['last_page_id'] = $Jobs->lastPage();
        $pagination['per_page'] = $Jobs->perPage();
        $pagination['nextPageUrl'] = $Jobs->nextPageUrl();
        $pagination['onFirstPage'] = $Jobs->onFirstPage();
        $pagination['previousPageUrl'] = $Jobs->previousPageUrl();
        $resonseData['paginate'] = $pagination;

        return response()->json([
            'status' => true,
            'message' => 'Success',
            'data' => $resonseData
        ]);
    }
}
